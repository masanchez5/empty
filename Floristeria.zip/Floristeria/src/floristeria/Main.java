/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package floristeria;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author formacio
 */
public class Main {
    //CONSTANTS
    final int OPTION1=1,OPTION2=2,OPTION3=3,OPTION4=4,OPTION5=5;
    
    //VARIABLES
    int option;
    boolean isCorrect=false;
    List<Shop> shops=new ArrayList<Shop>();
    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
       Main prg = new Main();
       prg.inici();
    }
    
    void inici(){     
        Scanner lector = new Scanner(System.in);
        
        do{
            
            
        
        }while (option!=OPTION5);
    }
    
        public void createShop(){
            String name;
            System.out.println ("Insert the name of the shop");
            codi=lector.nextLine();
            System.out.println("\n");
            
            System.out.println ("Introdueix el nombre de propulsors");
            numPropulsors=lector.nextInt();
            System.out.println("\n");
        }

        public void  addTree(){
           
        }

        public void addFlower(){
            
        }

        public void addDecoration(){
            
        }

         public void stock(){
            
        }
        
        
        public  int mostrarMenu(Scanner lector){

            isCorrect=false;
            System.out.println("Choose an option");
            System.out.println("-----------------------");
            System.out.println("1. Add tree");
            System.out.println("2. Add flower");                
            System.out.println("3. Add decoration");
            System.out.println("4. Create shop");
            System.out.println("5. Exit");
            System.out.println("\n");

            do {                         
            isCorrect = lector.hasNextInt();           
                      
                if (isCorrect) {
              
                option = lector.nextInt(); 

                    
                    if (option <OPTION1 || option>OPTION5){ 
                        System.out.println("Wrong input, try again");   
                       
                        isCorrect=false;
                    }

                }


            //El bucle do-while opera si es compleix que la dada es incorrecta                  
                } while (!isCorrect);
            //Es retorna el valor de la variable pregunta al programa inici

            return option;
        }
    }
    

