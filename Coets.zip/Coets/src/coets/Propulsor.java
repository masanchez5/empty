/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author formacio
 */
public class Propulsor {
    private int potenciaMax;
    private int potenciaActual;
    
    
    public Propulsor(int potenciaMax, int potenciaActual)throws Exception{
        
     
        this.potenciaMax = potenciaMax;
        this.potenciaActual=potenciaActual;
        
    }

    @Override
    public String toString() {
        return "Propulsor{" + potenciaMax + '}';
    }
    
    public int getIntActual() {
        return potenciaActual ;
    }
  
    public int getIntMaxima() {
        return potenciaMax ;
    }
    
    
        /*List<Integer> potenciesActuals = new ArrayList<Integer>();
        for (int i=0; i < coetArr.size(); i++) {
                    
         System.out.println("Indica la potencia objectiu");
         System.out.println("\n");

        } 
        return potenciesActuals;*/

    public void setPotenciaActual(int potenciaActual) {
        this.potenciaActual = potenciaActual;
    }
    
    
  
   
    
    
}   
    



   