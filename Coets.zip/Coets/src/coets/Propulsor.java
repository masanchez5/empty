/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author formacio
 */
public class Propulsor {
    private int potenciaMax;
    private int potenciaActual;
    
    
    public Propulsor(int potenciaMax, int potenciaActual)throws Exception{
        
     
        this.potenciaMax = potenciaMax;
        this.potenciaActual=potenciaActual;
        
    }

    @Override
    public String toString() {
        return "Propulsor{" + potenciaMax + '}';
    }

  
    
    
   
   
    
    
}   
    



   