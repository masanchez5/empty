/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author formacio
 */
public class Propulsor extends Thread {
    private int potenciaMax;
    private int potenciaActual;
    int objectiu;
    
    
    
    public void run() {
        
        //System.out.println("Indica la potencia objectiu sense superar la potencia maxima de " + potenciaMax);
        //int objectiu= Utils.indicarObjectiu();
       /*System.out.println("Potencia actual" + potenciaActual);
        System.out.println("Es comença a accelerar fins a la potencia objectiu " + objectiu + " sense superar la potencia maxima de "+potenciaMax);
        boolean esTroba=false;
        
        
        while(potenciaActual < objectiu && potenciaActual < potenciaMax){
            potenciaActual++;
            System.out.println( potenciaActual);
            try {
                sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Propulsor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        while(potenciaActual > objectiu){
           potenciaActual--; 
           System.out.println( potenciaActual);
            try {
                sleep(50000000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Propulsor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
                            
        System.out.println("\n"); 
        this.potenciaActual=potenciaActual;*/
        propulsar();
    }
      
    
    public Propulsor (int potenciaMax, int potenciaActual) {
        
     
        this.potenciaMax = potenciaMax;
        this.potenciaActual=potenciaActual;
        
       
        
    }
    
   
    
    public void propulsar (){
        
        System.out.println("Potencia actual" + potenciaActual);
        System.out.println("Es comença a accelerar fins a la potencia objectiu " + objectiu + " sense passar la maxima "+ potenciaMax);
        boolean esTroba=false;
        
        
        while(potenciaActual < objectiu && potenciaActual < potenciaMax){
            potenciaActual++;
            System.out.println(potenciaActual);
        }
        
        while(potenciaActual > objectiu){
           potenciaActual--; 
           System.out.println(potenciaActual);
        }
        
                            
        System.out.println("\n"); 
        this.potenciaActual=potenciaActual;
        
        /*do{
            System.out.println(potenciaActual); 
           
            if(potenciaActual < objectiu || potenciaActual < potenciaMax){
                potenciaActual++;
                System.out.println(potenciaActual);
                if(potenciaActual == objectiu || potenciaActual==potenciaMax){
                    esTroba=true;
                }
                
            }else if(potenciaActual > objectiu){
                potenciaActual--;
                System.out.println(potenciaActual);
                
                if(potenciaActual == objectiu){
                    esTroba=true;
                }
            }
            
        }while(!esTroba);*/
            //propulsorsObj.
        /*for (int j = 0; j < propulsorsObj.size(); j++) {
          
                       
                         
                        
        }*/
       
    }


    @Override
    public String toString() {
        return "Propulsor{" + potenciaActual + '}';
    }
    
    public int getIntActual() {
        return potenciaActual ;
    }
  
    public int getIntMaxima() {
        return potenciaMax ;
    }
    
    
        /*List<Integer> potenciesActuals = new ArrayList<Integer>();
        for (int i=0; i < coetArr.size(); i++) {
                    
         System.out.println("Indica la potencia objectiu");
         System.out.println("\n");

        } 
        return potenciesActuals;*/

    public void setPotenciaActual(int potenciaActual) {
        this.potenciaActual = potenciaActual;
    }

    public void setObjectiu(int objectiu) {
        this.objectiu = objectiu;
    }

   

    
           
}   
    



   