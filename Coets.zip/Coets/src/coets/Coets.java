/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 *
 * @author formacio
 */
public class Coets {
    //CONSTANTS
    static final short OPCIO1=1,OPCIO2=2,OPCIO3=3,OPCIO4=4;
    
    //VARIABLES
    int opcio;
    boolean esCorrecte=false;
    List<Coet> coetArr = new ArrayList<Coet>();
    
    Coet coet = new Coet (null,0,null);
    String codi;
   
    
     Scanner lector = new Scanner(System.in);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Coets prg = new Coets();
        prg.inici();
    }
    
    public void inici(){
         do{
            opcio=mostrarMenu();
            lector.nextLine();
            switch(opcio){                    
                case OPCIO1:
                    try {
                        
                        crearCoet();
                    } catch (Exception ex) {
                        System.out.println("Excepcio: "+ ex + " Has introduit camps buits");
                        System.out.println("\n");
                    }
                break;
                
                case OPCIO2:
                    try {
                        mostrarCoets();
                        //mostrarPotenciaMax();
                    } catch (Exception ex) {
                      System.out.println("Excepcio: "+ ex + " Has introduit camps buits");
                      System.out.println("\n");
                    } 
                               
                break;
                case OPCIO3:
                    try {
                        int posCoet= Utils.posCoet(coetArr);
                        coet=coetArr.get(posCoet);
                    } catch (Exception ex) {
                        System.out.println("Excepcio: "+ ex + " El coet no s'ha trobat a la llista");
                        System.out.println("\n");
                    }
                    
                break;
            }                                  
            
        }while (opcio!=OPCIO4);
    }
    
    //Mostra el menu a l'usuari amb les diferents opcions
    public  int mostrarMenu(){

        boolean  esCorrecte=false;
        System.out.println("Tria la opcio desitjada");
        System.out.println("-----------------------");
        System.out.println("1. Afegir coet");
        System.out.println("2. Mostrar coets");                
        System.out.println("3. Acelerar o frenar un coet");
        System.out.println("4. Sortir");
        System.out.println("\n");

        do {                         
        esCorrecte = lector.hasNextInt();           
        //El boolea sera cert si s'introdueix nombre enter           
            if (esCorrecte) {
            //Si la dada es un nombre sencer, es guarda a la variable corresponent.
            opcio = lector.nextInt(); 

                //Condicional que controla valors valids de la variable "pregunta".
                if (opcio <OPCIO1 || opcio>OPCIO4){ 
                    System.out.println("Dada erronia, torna a introduir.");   
                    //Els següents booleans son falsos si el nombre es incorrecte.
                    esCorrecte=false;
                }
                
            }
        

        //El bucle do-while opera si es compleix que la dada es incorrecta                  
            } while (!esCorrecte);
        //Es retorna el valor de la variable pregunta al programa inici
        
        return opcio;
    }
    
    public void crearCoet() throws Exception{
        int  numPropulsors;
        do{
            
            System.out.println ("Introdueix el codi de 8 caracters del coet");
            codi=lector.nextLine();
            System.out.println("\n");
            
            System.out.println ("Introdueix el nombre de propulsors");
            numPropulsors=lector.nextInt();
            System.out.println("\n");
            
            
            if (codi.equals("") || numPropulsors<=0){
                        throw new Exception();                                          
            }
            
            if ((codi.length())>3){
                System.out.println ("El codi que has introduit te mes de 8 caracters, torna a introduir");
                
                System.out.println("\n");
            }
            
            lector.nextLine();
            }while((codi.length())>3);
        
            //List<Integer> propulsors = new ArrayList<Integer>();
            List<Propulsor> propulsors = new ArrayList<Propulsor>();
            
            System.out.println ("Introdueix la potencia de cada propulsor");
            for (int i = 0; i < numPropulsors; i++) {

                int propulsor=lector.nextInt();
                if (propulsor<=0 ){
                    throw new Exception();                                          
                }

                propulsors.add(new Propulsor(propulsor,0));                           
               
            }
            System.out.println ("traça propulsors");
            
            //Metode per ordenar llista de propulsors
            /*int propulsorAux;
            for (int i = 0; i < numPropulsors-1; i++) {
                
                for (int j = i + 1; j < numPropulsors; j++) {
                    
                    if (propulsors.get(i)>propulsors.get(j)){
                       propulsorAux = propulsors.get(i);
                       propulsors.set(i,propulsors.get(j));
                       propulsors.set(j,propulsorAux);
                    }

                }          
               
            }*/           
            coetArr.add(new Coet(codi,numPropulsors,propulsors));
            System.out.println("\n");
    }
    
    
    public void mostrarCoets(){
        System.out.println (coetArr);
        System.out.println("\n");
        
    }
    
    /*public void mostrarPotenciaMax(){
        
        for (int i = 0; i < coetArr.size(); i++) {
            coet=coetArr.get(i);
            
            int potenciaMax=coet.getPropulsorMax();
            System.out.println("La potencia del propulsor mes potent del coet "+ coet.toStringName() + " es "+ potenciaMax);   
        }
        
        System.out.println("\n");
        
    }*/
    
    public List indicarActual(List<Coet> coetArr){
        List<Integer> potenciesActuals = new ArrayList<Integer>();
        for (int i=0; i < coetArr.size(); i++) {
                    
         System.out.println("Indica la potencia objectiu");
         System.out.println("\n");

        } 
        return potenciesActuals;
    }
}
