/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author formacio
 */
//Metodo start en esta clase

public class Coet {
    
    private String codi;
    private int numPropulsors;
    private int objectiu;
   
    //private List<Integer> propulsors = new ArrayList<Integer>(); 
    private List<Propulsor> propulsorsObj = new ArrayList<Propulsor>();
    
     
    public Coet(String codi,int numPropulsors,List<Propulsor> propulsors){
       
        this.codi=codi;
        this.numPropulsors=numPropulsors;
        this.propulsorsObj=propulsors;
        
    }
        
               
    
    
    @Override
    public String toString() {
        return "Coet{" + "codi=" + codi + ", numPropulsors=" + numPropulsors  + propulsorsObj + '}';
    }
    
    
    
    public String toStringName() {
        return codi ;
    }
    
    public int toIntNumProp() {
        return numPropulsors ;
    }

    

    public List<Propulsor> getPropulsors(int i) {
        return propulsorsObj;
    }
    
    /*public List<Integer> getPropulsorsActual(int i) {
        List<Integer> actuals = new ArrayList<Integer>();
        Propulsor propulsor;
        
        try {
            propulsor = new Propulsor(0,0);
        } catch (Exception ex) {
            Logger.getLogger(Coet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        int actual=0;
        
        for (int j = 0; j < propulsorsObj.size(); j++) {
            propulsor= propulsorsObj.get(j);
            actual= propulsor.getIntActual();
            actuals.add(actual);
                       
        }             
        return actuals;
    }*/
    
    /*public List<Integer> getPropulsorsMaxima(int i) {
        List<Integer> maximes = new ArrayList<Integer>();
        Propulsor propulsor;
        
        try {
            propulsor = new Propulsor(0,0);
        } catch (Exception ex) {
            Logger.getLogger(Coet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        int maxima=0;
        
        for (int j = 0; j < propulsorsObj.size(); j++) {
            propulsor= propulsorsObj.get(j);
            maxima= propulsor.getIntMaxima();
            maximes.add(maxima);
                       
        }             
        return maximes;*/
    
    
    
    /*public int getPropulsorMax() {
        
        int propulsorMax= propulsors.get(propulsors.size()-1);
        
        return propulsorMax ;
    }*/

    public List<Propulsor> getPropulsorsObj() {
        return propulsorsObj;
    }

    public void setPropulsorsObj(List<Propulsor> propulsorsObj) {
        this.propulsorsObj = propulsorsObj;
    }

    public int getObjectiu() {
        return objectiu;
    }

    public void setObjectiu(int objectiu) {
        this.objectiu = objectiu;
    }

    public void propulsar(List<Propulsor> propulsors){
        for (int k = 0; k < propulsors.size(); k++) {                      
                        propulsors.get(k).start();                  
        }
    }
    
    
}
