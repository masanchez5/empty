/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author formacio
 */

public class Coet {
    
    private String codi;
    private int numPropulsors;
   
    //private List<Integer> propulsors = new ArrayList<Integer>(); 
    private List<Propulsor> propulsorsObj = new ArrayList<Propulsor>();
    
     
    public Coet(String codi,int numPropulsors,List<Propulsor> propulsors){
       
        this.codi=codi;
        this.numPropulsors=numPropulsors;
        this.propulsorsObj=propulsors;
        
    }
    
    
            
    public int accelerar(int actual, int objectiu, int maxima){
        
        System.out.println("Potencia actual" + actual);
        System.out.println("Es comença a accelerar fins a la potencia objectiu " + objectiu + " sense passar la maxima "+maxima);
        boolean esTroba=false;
        do{
                      System.out.println(actual); 
                      actual++;
                      if(actual==maxima || actual==objectiu){
                        esTroba=true;
                      }
                    }while(!esTroba);
        System.out.println("\n");
        
        return actual;
    }
    
    
    public void frenar(int propulsor){           
                     
        System.out.println("\n");
        
    }

    
    
    @Override
    public String toString() {
        return "Coet{" + "codi=" + codi + ", numPropulsors=" + numPropulsors  + propulsorsObj + '}';
    }
    
    

   
    
    public String toStringName() {
        return codi ;
    }
    
    public int toIntNumProp() {
        return numPropulsors ;
    }

    

    public List<Propulsor> getPropulsors(int i) {
        return propulsorsObj;
    }
    
    public List<Integer> getPropulsorsActual(int i) {
        List<Integer> actuals = new ArrayList<Integer>();
        Propulsor propulsor;
        
        try {
            propulsor = new Propulsor(0,0);
        } catch (Exception ex) {
            Logger.getLogger(Coet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        int actual=0;
        
        for (int j = 0; j < propulsorsObj.size(); j++) {
            propulsor= propulsorsObj.get(j);
            actual= propulsor.getIntActual();
            actuals.add(actual);
                       
        }             
        return actuals;
    }
    
    public List<Integer> getPropulsorsMaxima(int i) {
        List<Integer> maximes = new ArrayList<Integer>();
        Propulsor propulsor;
        
        try {
            propulsor = new Propulsor(0,0);
        } catch (Exception ex) {
            Logger.getLogger(Coet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        int maxima=0;
        
        for (int j = 0; j < propulsorsObj.size(); j++) {
            propulsor= propulsorsObj.get(j);
            maxima= propulsor.getIntMaxima();
            maximes.add(maxima);
                       
        }             
        return maximes;
    }
    
    
    /*public int getPropulsorMax() {
        
        int propulsorMax= propulsors.get(propulsors.size()-1);
        
        return propulsorMax ;
    }*/

    
}
