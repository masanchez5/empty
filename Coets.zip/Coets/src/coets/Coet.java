/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author formacio
 */
public class Coet {
    private String codi;
    private int numPropulsors;
    private int potenciaActual;
    private List<Integer> propulsors = new ArrayList<Integer>(); 
    
    public Coet(String codi,int numPropulsors,List<Integer> propulsors){
        this.codi=codi;
        this.numPropulsors=numPropulsors;
        this.propulsors=propulsors;
        
    }

    

    @Override
    public String toString() {
        return "Coet{" + "codi=" + codi + ", propulsors=" + propulsors + '}';
    }
    
     public String toStringName() {
        return codi ;
    }

    

    public List<Integer> getPropulsors() {
        return propulsors;
    }
    
    public int getPropulsorMax() {
        
        int propulsorMax= propulsors.get(propulsors.size()-1);
        
        return propulsorMax ;
    }
    
    
}
