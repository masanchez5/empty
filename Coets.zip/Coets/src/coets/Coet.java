/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author formacio
 */
public class Coet {
    String codi;
    private int numPropulsors;
   
    //private List<Integer> propulsors = new ArrayList<Integer>(); 
    private List<Propulsor> propulsorsObj = new ArrayList<Propulsor>();
    private List<Integer> potObjectiu = new ArrayList<Integer>(); 
     
    public Coet(String codi,int numPropulsors,List<Propulsor> propulsors){
        this.codi=codi;
        this.numPropulsors=numPropulsors;
        this.propulsorsObj=propulsors;
        
        
    }
       
    
 
    public void accelerar(){
        int potObjectiu;
        System.out.println("Indica la potencia objectiu de cada propulsor del coet");
    }
    
    
    public void frenar(){
         int potObjectiu;
    }

    @Override
    public String toString() {
        return "Coet{" + "codi=" + codi + ", numPropulsors=" + numPropulsors  + propulsorsObj + '}';
    }
    
    

   
    
     public String toStringName() {
        return codi ;
    }

    

    public List<Propulsor> getPropulsors() {
        return propulsorsObj;
    }
    
    
    /*public int getPropulsorMax() {
        
        int propulsorMax= propulsors.get(propulsors.size()-1);
        
        return propulsorMax ;
    }*/
        
}
