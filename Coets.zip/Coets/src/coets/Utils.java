/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author formacio
 */
public class Utils {
    //Metode que retorna posicio d'un coet que es troba dins de la llista coets.
    public static int posCoet( List<Coet> coetArr) throws Exception{
        Scanner lector = new Scanner(System.in);
        int i = 0;
        String codiCoet;
        int posCoet=-1;
        String codi;
        
        System.out.println("Indica el codi del coet amb el qual vols treballar");
        codiCoet=lector.nextLine();
        
        for (i=0; i < coetArr.size(); i++) {
        Coet coet = new Coet (null, 0, null);
        coet= coetArr.get(i);
        
        codi=coet.toStringName();
        
        if ( codiCoet.equals(codi)){        
               posCoet=i;
            }    
        
         System.out.println("\n");

        }
        if(posCoet==-1){
            throw new Exception(); 
        }
        
        return posCoet;     
    }
    
    public static int posPropulsor( List<Propulsor> propulsorsObj) throws Exception{
        Scanner lector = new Scanner(System.in);
        int i = 0;
        int potPropulsor;
        int posPropulsor=-1;
        int propulsorReal;
        
        System.out.println("Indica la potencia maxima del propulsor amb el qual vols treballar");
        potPropulsor=lector.nextInt();
        
        for (i=0; i < propulsorsObj.size(); i++) {
        Propulsor propulsor = new Propulsor (0, 0);
        propulsor= propulsorsObj.get(i);
        
        propulsorReal=propulsor.getIntMaxima();
       
        if ( potPropulsor==(propulsorReal)){        
               posPropulsor=i;
            }    
        
         System.out.println("\n");

        }
        if(posPropulsor==-1){
            throw new Exception(); 
        }
        
        return posPropulsor;     
    }
    
    public static int indicarActual(List<Coet> coetArr, int i){
        
        Scanner lector = new Scanner(System.in);
        List<Integer> potObjectiu = new ArrayList<Integer>();
        Coet coet = new Coet (null,0,null);
        
        int numPropulsors;
            
        coet = coetArr.get(i);            
        System.out.println("Indica la potencia objectiu");
        int objectiu=lector.nextInt();
        
        
        
        System.out.println("\n");
        return objectiu;
    }
    
    
    public  static void indicarObjectiu(List<Propulsor> propulsors){
           
        int indica;
        Scanner lector = new Scanner(System.in);

        System.out.println("Indica la potencia objectiu");
        indica=lector.nextInt();


        for (int k = 0; k < propulsors.size(); k++) {
            propulsors.get(k).setObjectiu(indica);                      
        }
        System.out.println("\n");       
        } 
}


    
    
    

