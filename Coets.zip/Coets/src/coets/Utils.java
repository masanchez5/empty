/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author formacio
 */
public class Utils {
    //Metode que retorna posicio d'un coet que es troba dins de la llista coets.
    public static int posCoet( List<Coet> coetArr) throws Exception{
        Scanner lector = new Scanner(System.in);
        int i = 0;
        String codiCoet;
        int posCoet=-1;
        
        System.out.println("Indica el codi del coet amb el qual vols treballar");
        codiCoet=lector.nextLine();
        
        for (i=0; i < coetArr.size(); i++) {
        Coet coet = new Coet (null, 0, null);
        coet= coetArr.get(i);
        
        if ( codiCoet.equals(coet.codi)){        
               posCoet=i;
            }    
        
         System.out.println("\n");

        }
        if(posCoet==-1){
            throw new Exception(); 
        }
        
        return posCoet;     
    }
}
    
    
    

