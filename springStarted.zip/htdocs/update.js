

function putName() {
	var $answer=$('#answer');
	var variable = document.getElementById("myText").value	
    $.ajax({		
		type: 'GET',
		url: 'http://localhost:8080/greeting'+ '?name='+ variable,
		success: function(data) {
			
				$answer.append(data.content);
												
		}
		
		
	});
	
};
	
	
	
	
