const Alexa = require('alexa-sdk');



exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

const handlers = {
    'LaunchRequest': function () {
        this.emit('adivina_numero');
    },
    
    'adivina_numero': function () {
        
        
        // Se usa la funcion para obtener un número al azar entre 1 a 100
                 // Se crea un numero aleatorio y se guarda en un array como sesión
                 var guessNumber = getRandomInt(1,100);
               
                 // El número obtenido lo guardamos como variable de sesión, para que no se pierda.
                 this.attributes['guessNumber'] = guessNumber;
                 
                 // Esta variable cuenta el número de tentativas que vamos a tener para adivinar el número.
                 this.attributes['countContainer']=0;
                 
                
       this.response.cardRenderer('Adivina el número', 'Hola a todos');// Este es un mensaje para que aparezca echo show
       this.response.speak('Bienvenido a adivina el número. Estoy pensando un número entre 1 y 100. Adivina el número. Tienes sólo 7 oportunidades para ganar. Dime un número ').listen('');
       this.emit(':responseReady');
     
    },
    
    'AMAZON.HelpIntent': function () {
        const speechOutput = 'Hola, en este juego voy a pensar en un número entre 1 y 100 y tu lo tienes que adivinar. Puedes decir stop, para parar en cualquier momento. Puedes decir reinicia para volver a jugar.';
        const reprompt = 'Hola, por favor di un número entre 1 y 100';

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak('Gracias por usar el skill');
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak('Gracias por usar el skill');
        this.emit(':responseReady');
    },
    'NumeroIntent': function (){ // NumeroIntent es el Intent que creamos en Developer y tiene que ser el mismo que declaremos como función.
        
        var getNumber = this.event.request.intent.slots.NumeroSlot.value; // Este es el número que se recibe desde Alexa
                
        //Aquí controlamos los intentos para adivinar el numero
                
                 this.attributes['countContainer']=this.attributes['countContainer']+1;
               
        //Aquí controlamos si hemos acertado el número 
                
                if(this.attributes['guessNumber']==getNumber){
                    this.emit(':tell','Ganaste,  El numero era '+ this.attributes['guessNumber'] + ', Muy bien!!!! sigue asi ');
                    
                }
                else if(this.attributes['countContainer']==7){ // Aqui controla si hemos llegado al número máximo de intentos para adivinar el número.
                    this.emit(':tell',' Perdiste, el numero era '+this.attributes['guessNumber']+ ' . Lo siento, vuelve a intentarlo. Di Alexa empieza adivina el numero ');
                
                }
                else if (this.attributes['guessNumber']<getNumber){// Determinamos la condición si el numero que hemos dicho es mayor
                    this.emit(':ask', getNumber+ ', es muy alto. Prueba un numero menor.');
                    
                }
                else{//la condiciopn si el numero que hemos dicho es menor
                    this.emit(':ask', getNumber+ ', es muy bajo. Prueba un numero mas alto.');
                }
    },
    
    'EmpezarDeNuevo':function(){
                                
        var restart = this.event.request.intent.slots.Restart.resolutions.resolutionsPerAuthority[0].values[0].value.name
                                                                           
            if(restart=="reinicia"){
                this.attributes['guessNumber'] =0;
                this.attributes['countContainer']=0;
                this.emit('adivina_numero');
                           
            }else{
                this.emit(':tell', 'goodbye, Hasta luego.');
                                }
                
    },
};



// funcion que genere un numero ramdom de 1 a 100 donde min = 1 y max =100
function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
}