package com.ITAcademy.dices.Domains;

import javax.persistence.*;


import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Game", schema="dices_db")
public class Game {
	
	//@Column(name="id", insertable=false , updatable=false)
	private @Id @GeneratedValue Long id;
	
	
	//@Column(name="dice1")
	private  int dice1 = (int) ((Math.random()*((7-1)+1))+1);
	
	//@Column(name="dice2")
	private  int dice2 = (int) ((Math.random()*((7-1)+1))+1);
	
	private  int dice3 = (int) ((Math.random()*((7-1)+1))+1);
	private  int dice4 = (int) ((Math.random()*((7-1)+1))+1);
	private  int dice5 = (int) ((Math.random()*((7-1)+1))+1);
	private  int dice6 = (int) ((Math.random()*((7-1)+1))+1);
	
	//@Column(name="result")
	private int result= dice1+dice2;
	
	private int win=0;
	
	public Game(Player one){
		super();
		//this.id_player = id_player;
		this.player=one;
		if(this.result==6 ||this.result==5 ) {
			
			this.win=1;
		}
		
	}
	
	
	
	public Game(int dice1, int dice2, int result, Player player) {
		super();
		this.dice1 = dice1;
		this.dice2 = dice2;
		this.result = result;
		this.player = player;
		//this.id_player = id_player;
	}

	

	public Game() {
		// TODO Auto-generated constructor stub
	}



	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_player", nullable = false) //id_player is attribute in the dices DB.
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Player player;
	//@Column(name="id_player")
	//private Long id_player;
	
//	private void setId_player() {
//		this.id_player=player.getId();
//		
//	}
//	
//	private Long getId_player() {
//		this.id_player=player.getId();
//		return id_player;
//	}
	

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public Player getPlayer() {
		return player;
	}
	
	public Long getIdPlayer() {
		return player.getId();
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getDice1() {
		return dice1;
	}

	public void setDice1(int dice1) {
		this.dice1 = dice1;
	}

	public int getDice2() {
		return dice2;
	}

	public void setDice2(int dice2) {
		this.dice2 = dice2;
	}
	
	public int getWin() {
		return win;
	}



	public int getDice3() {
		return dice3;
	}



	public void setDice3(int dice3) {
		this.dice3 = dice3;
	}



	public int getDice4() {
		return dice4;
	}



	public void setDice4(int dice4) {
		this.dice4 = dice4;
	}



	public int getDice5() {
		return dice5;
	}



	public void setDice5(int dice5) {
		this.dice5 = dice5;
	}



	public int getDice6() {
		return dice6;
	}



	public void setDice6(int dice6) {
		this.dice6 = dice6;
	}



	public void setWin(int win) {
		this.win = win;
	}
		
	
}

