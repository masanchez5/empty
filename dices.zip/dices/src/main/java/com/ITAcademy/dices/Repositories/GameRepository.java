package com.ITAcademy.dices.Repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ITAcademy.dices.Domains.Game;
import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;



public interface GameRepository extends JpaRepository<Game, Long> {
	List<Game> findByPlayerId(Long playerId);
    //Optional<Game> findByIdAndPlayerId(Long gameId, Long playerId);
    public void deleteById(Long id);
	//Optional<Game> findByplayerId(Long playerId);
	//long countbyId(Long playerId);
	 @Override
	    void deleteAll();
	 
}
