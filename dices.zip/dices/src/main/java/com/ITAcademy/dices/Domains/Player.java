package com.ITAcademy.dices.Domains;


import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;


import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Player", schema="dices_db")
public class Player {
	

private @Id Long id;


private String name;

private LocalDateTime register =  LocalDateTime.now() ;

private double success=0;

private long win=0;

//private long count=1;
//private List<Picture> pictures = new ArrayList<Picture>();
//private final PictureRepository repository;

public Player() {
		this.name= "ANONIM";		
}

public Player(long id,String name) {
	this.id=id;																						
	this.name = name;
												
}

public Long getId() {
	return id;
}

public void setId(Long idPlayer) {
	this.id = idPlayer;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public void setSuccess(long win, long count) {
	
		this.win += win;
		this.success=((double)(this.win)/(count+1))*100;
	
	
}

public double getSuccess() {
	return success;
}


public long getWin() {
	return win;
}

public void setWin(long win) {
	this.win = win;
}

public void setSuccess(double success) {
	this.success = success;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Player other = (Player) obj;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	return true;
}




}
