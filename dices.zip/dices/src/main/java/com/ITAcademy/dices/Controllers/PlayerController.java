package com.ITAcademy.dices.Controllers;

import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

import javax.validation.Valid;
import javax.xml.ws.Holder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ITAcademy.dices.Domains.Player;
import com.ITAcademy.dices.Domains.PlayerNotFoundException;
import com.ITAcademy.dices.Repositories.PlayerRepository;


@RestController
public class PlayerController {
	@Autowired
	private  PlayerRepository playerRepository;

	@GetMapping("/players")
		List<Player> getAllPlayers() {
	    return  playerRepository.findAll();
	}
	
	
	@GetMapping("/players/ranking")
		double totalRanking(){
		double totalRanking=0;
		double sum=0;
		int count=0;
		List <Player> allRankings= playerRepository.findAll();
		for (Player playerOne : allRankings) {
				sum+=playerOne.getSuccess();
				count++;
							
		}
		totalRanking=sum/count;
		
			return totalRanking;
		
	}
	
	@GetMapping("/players/ranking/loser")
	Player loser() {
		
		List <Player> allPlayers=playerRepository.findAll();
		Player loser = allPlayers
			      .stream()
			      .min(Comparator.comparing(Player::getSuccess))
			      .orElseThrow(NoSuchElementException::new);
		return loser;
		
	}
	
	@GetMapping("/players/ranking/winner")
	Player winner() {
		
		List <Player> allPlayers=playerRepository.findAll();
		Player winner = allPlayers
			      .stream()
			      .max(Comparator.comparing(Player::getSuccess))
			      .orElseThrow(NoSuchElementException::new);
		return winner;
		
	}

	//Post request to add players
	//@CrossOrigin(origins = "http://localhost:8080")
	@PostMapping("/players")
	public Player createPlayer(@Valid @RequestBody Player player) {
		boolean isFound=false;
		List <Player> checkPlayer = getAllPlayers();
		
		//foreach loop to check if the new player is already in the repository
		for (Player playerOne : checkPlayer) {  
			//condition when player is in the repository excluding if it is ANONIM
			if (((player.getName().equals(playerOne.getName())) && !(player.getName().equals("ANONIM"))))  {//|| (player.getId().equals(playerOne.getId()
				isFound=true;
				String name="This player is already set up";
				player.setName(name);		
			//condition to set ANONIM player when name is empty				
			}else if(player.getName().equals("")) {
				player.setName("ANONIM");
			//condition to update player when id sent on HTTP request is in the repository	
			}else if((player.getId().equals(playerOne.getId()))){
				playerOne.setName(player.getName());
			}
		}
				
		if (isFound) {
			return player;
		}else{
			return playerRepository.save(player);
		}
		
	}
	
	
	//Post player del 26 de febrer al mati
//	@PostMapping("/players")
//	public Player createPlayer(@Valid @RequestBody Long id, @Valid @RequestBody Player player) {
//		boolean isFound=false;
//		List <Player> checkPlayer = getAllPlayers();
//		
//		//foreach loop to check if the new player is already in the repository
//		for (Player playerOne : checkPlayer) {
//			if ((player.getName().equals(playerOne.getName()) && !(player.getName().equals("ANONIM")))) {
//				isFound=true;
//				String name="This player is already set up";
//				player.setName(name);		
//							
//			}else if(player.getName().equals("")) {
//				player.setName("ANONIM");
//				
//			}
//		}
//		
//				
//		if (isFound) {
//			return player;
//		}else{
//			return playerRepository.save(player);
//		}
//		
//	}
	
//	@PostMapping("/players")
//	public Player createAnonimous() {
//		Player anonimous=new Player();
//		String name ="ANONIM";
//				
//		anonimous.setName(name);		
//				
//		return playerRepository.save(anonimous);
//		
//	}

	// Single item

	@GetMapping("/players/{id}")
	Player one(@PathVariable Long id) {
	//
	return playerRepository.findById(id)

	.orElseThrow(() -> new PlayerNotFoundException(id));
	//
	//}

	}
	
}

