package com.ITAcademy.dices.Controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ITAcademy.dices.Domains.Game;
import com.ITAcademy.dices.Domains.Player;
import com.ITAcademy.dices.Domains.PlayerNotFoundException;
import com.ITAcademy.dices.Repositories.GameRepository;
import com.ITAcademy.dices.Repositories.PlayerRepository;
import com.ITAcademy.dices.Domains.ResourceNotFoundException;

@RestController
public class GameController {

	@Autowired
	private  GameRepository gameRepository;
	 
	@Autowired
	private   PlayerRepository playerRepository;
	
	
//	public PictureController(){
//		
//	}
//	PictureController(@PathVariable("id") Long repositoryPic) {
//
//	this.picRepository = (PictureRepository) repositoryPic;
//
//	}
	
	
	
	
//	List<Picture> all() {
//
//		return repositoryPic.findAll();
//
//		}

	@GetMapping("/players/{playerId}/games")
	public List<Game> getAllGamesByPlayerId(@PathVariable (value = "playerId") Long playerId) {
		return gameRepository.findByPlayerId(playerId);
	}

		//Post request to add pictures

		

//		Picture newPicture(@RequestBody Picture newPicture) {
//
//		return repositoryPic.save(newPicture);
//
//		}
	
	
		@PostMapping("/players/{playerId}/games")                                  //, @Valid @RequestBody Game game
		public  Game createGame(@PathVariable (value = "playerId") Long playerId ) {
			Player one= playerRepository.findById(playerId)
					.orElseThrow(() -> new PlayerNotFoundException(playerId));
			Game game=new Game(one);
			long count = countById(playerId);
			int win= game.getWin();
			
			one.setSuccess(win,count);
//			boolean isPossible=false;
//			isPossible = checkCapacity(shopId);
//			if(isPossible) {
			return playerRepository.findById(playerId).map(player -> {
			game.setPlayer(player);
			return gameRepository.save(game);
			}).orElseThrow(() -> new ResourceNotFoundException("playerId " + playerId + " not found"));
//			}else {
//				return null;
//			}
		}
		
		public long countById(Long playerId) {
			long add=0;
			List<Game> allGames=getAllGamesByPlayerId(playerId);
			for (Game game : allGames) {
				add++;
			}
			//Game game = gameRepository.findById(id)
			//.orElseThrow(() -> new GameNotFoundException(shopId));
			gameRepository.count();
			return add;
			
		}
		
		@DeleteMapping(value = "/players/{playerId}/games")
		public void deleteGames(@PathVariable("playerId") long playerId) {
			List<Long> idGames = new ArrayList <Long>();
			List <Game> allGames = gameRepository.findByPlayerId(playerId);
			Player one = playerRepository.findById(playerId)
					.orElseThrow(() -> new PlayerNotFoundException(playerId));
			one.setWin(0);
			one.setSuccess(0);
			for (Game game : allGames) {
				if(game.getIdPlayer()==playerId) {
					idGames.add(game.getId());
				}
		        
		    }
			
		    for (Long id : idGames) {

		        gameRepository.deleteById(id);

		    }

		}
					
}		



