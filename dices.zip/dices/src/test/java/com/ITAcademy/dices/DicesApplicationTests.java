package com.ITAcademy.dices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
