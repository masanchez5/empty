package com.jobs.domain;

public class Volunteer extends AbsStaffMember {
	
	protected IPaymentRate paymentRate;	
	private int salary;
	public Volunteer(String name, String address, String phone, int i) throws Exception {
		super(name, address, phone);
		this.salary=i;
		
	}
	
	@Override
	public void pay() {
		//TODO
		totalPaid=paymentRate.pay(0);
	}

}
