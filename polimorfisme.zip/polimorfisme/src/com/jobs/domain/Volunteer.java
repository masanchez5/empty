package com.jobs.domain;

public class Volunteer extends AbsStaffMember {
	
	protected double salaryPerMonth;
	protected IPaymentRate paymentRate;	
	
	public Volunteer(String name, String address, String phone,double salaryPerMonth, IPaymentRate paymentRate) throws Exception {
		super(name, address, phone);
		this.salaryPerMonth=salaryPerMonth;
		this.paymentRate=paymentRate;
		
	}
	
	@Override
	public void pay() {
		//TODO
		totalPaid=paymentRate.pay(salaryPerMonth);
	}

	@Override
	public String toString() {
		return "Volunteer [salaryPerMonth=" + salaryPerMonth + ", id=" + id + ", name=" + name + ", address=" + address
				+ ", phone=" + phone + ", totalPaid=" + totalPaid + "]";
	}
	

}
