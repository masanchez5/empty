package com.jobs.domain;

public class Volunteer extends AbsStaffMember {
	
	protected IPaymentRate paymentRate;	
	private String description;
	public Volunteer(String name, String address, String phone, String description) throws Exception {
		super(name, address, phone);
		this.description=description;
		
	}
	
	@Override
	public void pay() {
		//TODO
		totalPaid=paymentRate.pay(0);
	}

}
