package com.jobs.domain;

public interface IPaymentRate {
	public double pay(double salaryPerMonth);
	
	
}
