package com.jobs.persistence;

import java.util.ArrayList;
import java.util.List;

import com.jobs.domain.AbsStaffMember;
import com.jobs.domain.Employee;
import com.jobs.domain.Volunteer;

public class EmployeeRepository {

	private static List<AbsStaffMember> members=new ArrayList<>();
	
	public EmployeeRepository(){
		
	}
	
	public List<AbsStaffMember> getAllMembers(){
		return new ArrayList<>(members);
	}
	
	
	public void addMember(AbsStaffMember member) throws Exception{
		if(member==null) throw new Exception();
		members.add(member);
	}

	@Override
	public String toString() {
		return "EmployeeRepository [getAllMembers()=" + getAllMembers() + "]";
	}

	

	public Employee getEmployee(int i) {
		Employee member = (Employee) members.get(i);
		return member;
	}
	
	
	public Volunteer getVolunteer(int i) {
		Volunteer member = (Volunteer) members.get(i);
		return member;
	}
	
	public AbsStaffMember getStaff(int i) {
		AbsStaffMember member = (AbsStaffMember) members.get(i);
		return member;
	}
	

	public static void setMembers(List<AbsStaffMember> members) {
		EmployeeRepository.members = members;
	}

	
	
	
}
