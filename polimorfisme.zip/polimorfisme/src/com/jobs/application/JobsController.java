package com.jobs.application;

import java.util.Iterator;
import java.util.List;

import com.jobs.domain.AbsStaffMember;
import com.jobs.domain.Employee;
import com.jobs.domain.Volunteer;
import com.jobs.persistence.EmployeeRepository;

public class JobsController {

	private static EmployeeRepository repository= new EmployeeRepository();
	
	
	
	
	public JobsController() {
		
	}
	
	
	public void createBossEmployee(String name, String address, String phone, double salaryPerMonth) throws Exception{		
		Employee boss = new Employee(name, address, phone,  salaryPerMonth, PaymentFactory.createPaymentRateBoss());
		repository.addMember(boss);
	}
	
	public void createEmployee(String name, String address, String phone, double salaryPerMonth) throws Exception{		
		Employee boss = new Employee(name, address, phone,  salaryPerMonth, PaymentFactory.createPaymentRateEmployee());
		repository.addMember(boss);
	}

	public void createManagerEmployee(String name, String address, String phone, double salaryPerMonth) throws Exception{
		Employee boss = new Employee(name, address, phone,  salaryPerMonth, PaymentFactory.createPaymentRateManager());
		repository.addMember(boss);
		
	}
	
	public void createVolunteer(String string, String string2, String string3,double salaryPerMonth) throws Exception {
		Volunteer boss = new Volunteer(string, string2, string3,salaryPerMonth,PaymentFactory.createPaymentRateVolunteer());
		repository.addMember(boss);
		
	}
	

	public void payAllEmployeers() {
		//for (int i = 0; i < repository.getAllMembers().size(); i++) {
		int i=0;
		for (AbsStaffMember AbsStaffMember : repository.getAllMembers()) {
			
			if(repository.getStaff(i) instanceof Employee) {
			repository.getEmployee(i).pay();
			}else if(repository.getAllMembers() instanceof Volunteer){
				repository.getVolunteer(i).pay();
			}
			
			i++;
		}
		
	}

	public String getAllEmployees() {
		
		// TODO Auto-generated method stub
		return "[repository=" + repository + "]";
	}


	
	
	


	public static EmployeeRepository getRepository() {
		return repository;
	}
	
	
	
}
