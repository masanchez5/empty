package com.jobs.application;

import java.util.Iterator;

import com.jobs.domain.Employee;
import com.jobs.domain.Volunteer;
import com.jobs.persistence.EmployeeRepository;

public class JobsController {

	private static EmployeeRepository repository= new EmployeeRepository();
	
	
	public JobsController() {
		
	}
	
	
	public void createBossEmployee(String name, String address, String phone, double salaryPerMonth) throws Exception{		
		Employee boss = new Employee(name, address, phone,  salaryPerMonth, PaymentFactory.createPaymentRateBoss());
		repository.addMember(boss);
	}
	
	public void createEmployee(String name, String address, String phone, double salaryPerMonth) throws Exception{		
		Employee boss = new Employee(name, address, phone,  salaryPerMonth, PaymentFactory.createPaymentRateEmployee());
		repository.addMember(boss);
	}

	public void createManagerEmployee(String name, String address, String phone, double salaryPerMonth) throws Exception{
		Employee boss = new Employee(name, address, phone,  salaryPerMonth, PaymentFactory.createPaymentRateManager());
		repository.addMember(boss);
		
	}
	
	

	public void payAllEmployeers() {
		for (int i = 0; i < repository.getAllMembers().size(); i++) {
			
			repository.getEmployee(i).pay();
			
		}
		
	}

	public String getAllEmployees() {
		// TODO Auto-generated method stub
		return "[repository=" + repository + "]";
	}




	public void createVolunteer(String string, String string2, String string3,int i) throws Exception {
		Volunteer boss = new Volunteer(string, string2, string3,i);
		repository.addMember(boss);
		
	}


	public static EmployeeRepository getRepository() {
		return repository;
	}
	
	
	
}
