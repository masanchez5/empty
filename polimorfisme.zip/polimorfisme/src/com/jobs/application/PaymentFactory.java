package com.jobs.application;

import com.jobs.domain.IPaymentRate;

public class PaymentFactory {

	private static double realSalary=0;
	
	public static IPaymentRate createPaymentRateBoss(){
		return new IPaymentRate() {	
			@Override
			public double pay(double salaryPerMonth) {
				realSalary=salaryPerMonth*1.5;
				return realSalary;
			}
		};
		
	}
	
	public static IPaymentRate createPaymentRateEmployee(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return realSalary= salaryPerMonth*0.85;//todo. CANVI DE RETURN 0 A RETURN ACTUAL
			}
		};
	}
		
	//INTERFACE NOVA PEL CAS MANAGER
	public static IPaymentRate createPaymentRateManager(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return realSalary=salaryPerMonth*1.1;
			}
		};
	}
	
	public static IPaymentRate createPaymentRateVolunteer(){
		return new IPaymentRate() {
			@Override
			public double pay(double salaryPerMonth) {
				return realSalary=salaryPerMonth;
			}
		};
	}


	

	
}

