

function readRepository() {
    var $answer1=$('#answer1');	
    
    $.ajax({		
		type: 'GET',
		url: 'http://localhost:8080/employees/',
		success: function(reponse) {
            
            $.each(reponse,function(i,item){
                $answer1.append( item.name + " " + item.role + "<br>");
                
            });    
        }
                //document.write(JSON.stringify(data))
                //console.log(JSON.stringify(data))
                //Print name with append
				
												
		
		
		
	});
	
};

function readEmployee() {
	var $answer2=$('#answer2');
	var variable1 = document.getElementById("myText").value	
    $.ajax({		
		type: 'GET',
		url: 'http://localhost:8080/employees/'+ variable1,
		success: function(data) {
            $answer2.append( data.name + " " + data.role + "<br>");
                
												
		}
		
		
	});
	
};


function addEmployee() {
	
    var $answer3=$('#answer3');
    var newEmp={
        empId:$("#newId").val(),
        empName:$("#newName").val(),
        empRole:$("#newRole").val()
    }

    $.ajax({		
        type: 'POST',
        contentType:"application/json",
        url: 'http://localhost:8080/employees/',
        data:JSON.stringify(newEmp),
        dataType:'json',
		success: function(result) {
            $answer3.append( "succesful" );
                //Print name with append
				//$answer.append(data.name);
												
		}
		
		
	});
	
};