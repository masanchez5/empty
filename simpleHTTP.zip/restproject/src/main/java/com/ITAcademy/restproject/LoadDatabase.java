package com.ITAcademy.restproject;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ITAcademy.restproject.Domains.Employee;
import com.ITAcademy.restproject.Domains.EmployeeRepository;

@Configuration

public class LoadDatabase {

@Bean

CommandLineRunner initDatabase(EmployeeRepository repository) {

return args -> {

System.out.println("Preloading Data to memoryDatabase");

repository.save(new Employee("Bilbo Baggins", "burglar"));

repository.save(new Employee("Frodo Baggins", "thief"));

System.out.println("Data loaded");

};

}

}