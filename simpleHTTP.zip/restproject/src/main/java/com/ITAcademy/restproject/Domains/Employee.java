package com.ITAcademy.restproject.Domains;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity

public class Employee {

private @Id @GeneratedValue Long id;

private String name;

private String role;

public Employee() {}

public Employee(String name, String role) {

this.name = name;

this.role = role;

}

public String getName() {
	// TODO Auto-generated method stub
	return this.name;
}

public String getRole() {
	// TODO Auto-generated method stub
	return this.role;
}

public Long getId() {
	// TODO Auto-generated method stub
	return this.id;
}

public void setName(String name2) {
	// TODO Auto-generated method stub
	this.name=name2;
	
}

public void setRole(String role2) {
	// TODO Auto-generated method stub
	this.role=role2;
}

public void setId(Long id2) {
	// TODO Auto-generated method stub
	this.id=id2;
	
}

}