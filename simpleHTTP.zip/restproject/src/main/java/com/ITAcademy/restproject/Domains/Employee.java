package com.ITAcademy.restproject.Domains;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;



@Entity

public class Employee {

private @Id @GeneratedValue Long id;
@NotNull(message="the name can't be null")
private String name;
@NotNull(message="the role can't be null")
private String role;
private EnumJobs jobs;
private int salary;

public Employee() {
	
}


public Employee(String name, String role) {


		this.name = name;
		this.role = role;
		
		for (int i = 0; i < jobs.values().length; i++) {
			if (role.equals("burglar")) {
				this.salary=1000;
			}else if(role.equals("thief")) {
				this.salary=2000;
			}else if(role.equals("knight")) {
				this.salary=3000;
			}else if(role.equals("witch")) {
				this.salary=4000;
			}
		}
		
//		for (EnumJobs jobs :EnumJobs.values()) { 
//			if (role.equals(jobs.getValue())) {
//				
//			}
//		}
	}






public String getName() {
	// TODO Auto-generated method stub
	return this.name;
}

public String getRole() {
	// TODO Auto-generated method stub
	return this.role;
}

public Long getId() {
	// TODO Auto-generated method stub
	return this.id;
}


public int getSalary() {
	return salary;
}


public void setSalary(int salary) {
	this.salary = salary;
}


public void setName(String name2) {
	// TODO Auto-generated method stub
	this.name=name2;
	
}

public void setRole(String role2) {
	// TODO Auto-generated method stub
	this.role=role2;
}

public void setId(Long id2) {
	// TODO Auto-generated method stub
	this.id=id2;
	
}

}