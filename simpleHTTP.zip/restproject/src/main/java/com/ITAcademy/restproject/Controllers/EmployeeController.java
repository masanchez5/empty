package com.ITAcademy.restproject.Controllers;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import com.ITAcademy.restproject.Domains.Employee;
import com.ITAcademy.restproject.Domains.EmployeeNotFoundException;
import com.ITAcademy.restproject.Domains.EmployeeRepository;
//import org.springframework.web.bind.annotation.RequestMethod;
//
//@CrossOrigin(										// Implementación de CORS (Cross-Origin Resource Sharing)
//		origins = { "http://localhost:80" },		// Dominio o IP del servidor ( Local host de ANGULAR "http://localhost:4200")
//		methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE}	// Metodos permitidos
//		)



@RestController

//@RequestMapping("/api")

public class EmployeeController {

private final EmployeeRepository repository;

EmployeeController(EmployeeRepository repository) {

this.repository = repository;

}

//@Bean
//public WebMvcConfigurer corsConfigurer() {
//	return new WebMvcConfigurer() {
//		@Override
//		public void addCorsMappings(CorsRegistry registry) {
//			registry.addMapping("/employees").allowedOrigins("http://localhost:8080");
//			registry.addMapping("/employees").allowedOrigins("http://localhost:80");
//			registry.addMapping("/employees").allowedOrigins("http://localhost:443");
//			registry.addMapping("/employees").allowedOrigins("http://localhost:5222");
//			registry.addMapping("/employees").allowedOrigins("http://localhost/api/index.html");
//	}
//	};
//}

//Controller 1
// Aggregate root


@RequestMapping("/employees")
//@CrossOrigin(origins = "http://localhost/index.html")

List<Employee> all() {

return repository.findAll();

}

//Controller 2

@PostMapping("/employees")


Employee newEmployee(@RequestBody Employee newEmployee) {

return repository.save(newEmployee);

}

// Single item

@GetMapping("/employees/{id}")

Employee one(@PathVariable Long id) {

return repository.findById(id)

.orElseThrow(() -> new EmployeeNotFoundException(id));

}

//Controller 3

@PutMapping("/employees/{id}")

Employee replaceEmployee(@RequestBody Employee newEmployee, @PathVariable Long id) {

return repository.findById(id)

.map(employee -> {

employee.setName(newEmployee.getName());

employee.setRole(newEmployee.getRole());

return repository.save(employee);

})

.orElseGet(() -> {

newEmployee.setId(id);

return repository.save(newEmployee);

});

}

@DeleteMapping("/employees/{id}")

void deleteEmployee(@PathVariable Long id) {

repository.deleteById(id);

}

}

