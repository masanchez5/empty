package com.ITAcademy.pictures.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ITAcademy.pictures.Domains.Picture;

public interface PictureRepository extends JpaRepository<Picture, Long> {
	

}