package com.ITAcademy.pictures;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicturesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicturesApplication.class, args);
	}

}
