package com.ITAcademy.pictures.Domains;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

public class Shop {
	private @Id @GeneratedValue Long id;
	@NotNull(message="the name can't be null")
	
	private String name;
	private int capacity;	
	private List<Picture> pictures = new ArrayList<Picture>();
	
	public Shop() {
		
	}

	public Shop(String name, int capacity) {
									
					this.name = name;
					this.capacity = capacity;
					
				
		
	}

	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}

	

	public Long getId() {
		// TODO Auto-generated method stub
		return this.id;
	}


}
