package com.ITAcademy.pictures.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ITAcademy.pictures.Domains.Shop;

public interface ShopRepository extends JpaRepository<Shop, Long> {
	

}