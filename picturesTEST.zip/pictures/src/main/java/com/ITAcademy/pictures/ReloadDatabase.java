package com.ITAcademy.pictures;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ITAcademy.pictures.Domains.Shop;
import com.ITAcademy.pictures.Repositories.ShopRepository;

@Configuration

public class ReloadDatabase {

@Bean

CommandLineRunner initDatabase(ShopRepository repository) {

return args -> {

System.out.println("Preloading Data to memoryDatabase");

repository.save(new Shop("Bilbo Baggins", 1000));

repository.save(new Shop("Frodo Baggins",2000));

System.out.println("Data loaded");

};

}

//public WebMvcConfigurer corsConfigurer() {
//	return new WebMvcConfigurer() {
//		@Override
//		public void addCorsMappings(CorsRegistry registry) {
//			registry.addMapping("/employees").allowedOrigins("http://localhost:5222  ");
//		}
//	};
//}

}