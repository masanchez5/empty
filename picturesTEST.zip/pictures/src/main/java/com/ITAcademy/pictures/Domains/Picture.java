package com.ITAcademy.pictures.Domains;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

public class Picture {
	private @Id @GeneratedValue Long id;
	
	private String name;
	private String author;
	
	public Picture(String name, String author) {
		this.name=name;
		this.author=author;
	}
	

	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}
	

	public String getAuthor() {
		// TODO Auto-generated method stub
		return this.author;
	}
	

	public Long getId() {
		// TODO Auto-generated method stub
		return this.id;
	}
}
