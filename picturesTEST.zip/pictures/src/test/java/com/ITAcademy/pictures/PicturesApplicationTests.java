package com.ITAcademy.pictures;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PicturesApplicationTests {

	@Test
	void contextLoads() {
	}

}
