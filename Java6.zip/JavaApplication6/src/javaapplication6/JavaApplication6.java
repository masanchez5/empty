
package javaapplication6;

import java.io.File;

/**
 *
 * Repte 1. Feu un programa que llegeixi successivament 15 valors de tipus real des d’un fitxer anomenat “Reals.txt”. 
 * Aquest fitxer el podeu fer vosaltres mateixos. El programa ha de mostrar quin dels valors dins el fitxer és el més gran.
 */
/*
public class JavaApplication6 {

    public static void main(String[] args) {
        //GESTIO DE FITXERS
        //REPTE 1
        String s ="C:/Users/formacio/Documents/doc.txt";
        File f = new File(s);
        File f2 = new File ("C:/Users/formacio/Documents/crea");
        File f3 = new File("C:/Users/formacio/Documents/creacio");
        
        System.out.println("getName " + f.getName());
        System.out.println("getParent " + f.getParent());
        System.out.println("getAbsolutePath " + f.getAbsolutePath());
        System.out.println("isFile " + f.isFile());
        System.out.println("isDirectory " + f.isDirectory());
        
        boolean crea=f2.mkdir();
        
        //boolean borra=f2.delete();
        System.out.println("mkdir  " + crea);
        //System.out.println("delete  " + borra);
        boolean renombra= f2.renameTo(f3);
        System.out.println("renameTo  " + renombra);
        
        
        String name = f.getName();
        String route = f.getParent();
        int pos = name.lastIndexOf(".");
        String newName="";
        System.out.println("lastIndexOf  " + name.lastIndexOf("."));
        if (pos > 0){
            
            for (int i = 0; i < pos; i++) {
                char c=' ';
                c = name.charAt(i);
                newName+=c;
            }
        }
        System.out.println("newName " + newName);
        String newPath= route + File.separator + newName;
        System.out.println("newPath " + newPath);
        File f4 =new File(newPath);
        boolean renombra2 = f.renameTo(f4);
        System.out.println("renombra repte 1 " + renombra2);
        System.out.println("getName modificat " + f4.getAbsolutePath());
        //FI REPTE 1
          
    }
        
        
}       
        
    
    
}
*/