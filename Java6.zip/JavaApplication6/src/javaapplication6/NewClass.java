/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author formacio
 * Repte 2. Realitzeu un programa que llegeixi des del teclat el text associat a la ruta
a una carpeta existent dins del vostre ordinador. Esborrar tots els elements que hi
ha dins, independentment que siguin fitxers o carpetes. Tingueu en compte que
per poder eliminar una carpeta cal abans buidar-la de tot el seu contingut (en la
qual hi pot haver alhora tant fitxers o carpetes... i així indefinidament fins a arribar
a una carpeta que només té fitxers). Pista: Per resoldre aquest problema és molt
més senzill plantejar una solució recursiva.
 * 
 */

public class NewClass {

    public static void main(String[] args) {
    NewClass programa = new NewClass();
    programa.inici();
    }
    //GESTIO DE FITXERS. REPTE 2   
    public void inici() {
        //Carpeta de la que es vol eliminar tot l'arbre de fitxers i carpetes
        //File f5 = new File("C:/Users/formacio/Documents/repte2");
        //borra(f5);
        llegirFitxer();
    }
    

        
    public  void borra(File f){     
        File[] elements = f.listFiles();
        System.out.println("file elements ");

        for (int i = 0; i < elements.length; i++) {
             System.out.println( elements[i]);
             if(elements[i].isFile()){
                 elements[i].delete();

             } else if(elements[i].isDirectory()){
                String route=elements[i].getAbsolutePath();
                File f2 = new File(route);

                borra(f2);
                elements[i].delete();
             }
        }
    }
    //TRACTAMENT BASIC DE DADES. REPTE 1
    static final String FI="fi";
    public  void llegirFitxer(){     
        try {
            File f = new File("C:/Users/formacio/Documents/doc.txt");
            Scanner sc=new Scanner (f);
            String paraula="";
            int enter;
            while(!(paraula.equals(FI))){
                enter=sc.nextInt();
                paraula = sc.next();
                System.out.println(enter);
                System.out.println(paraula);
            }
            sc.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(NewClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
           
}